#!/usr/bin/env python3
"""
BOSS Dev Engine Terminal Manager v0.2.0

Logical persistent sessions:
- Persistent session records and command history
- Working-directory restoration between commands
- Durable output logs and exit codes
- Background task tracking and termination
- Stale-process detection

Important:
This is not an Android Foreground Service.
A logical session does not preserve shell variables, functions,
or an interactive shell process between CLI invocations.
"""

import argparse
import json
import os
import shlex
import signal
import subprocess
import sys
import time
import uuid

from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
BASE = ROOT / "terminal"
SESSIONS = BASE / "sessions"
LOGS = BASE / "logs"
TASKS = BASE / "tasks"
STATE = BASE / "state" / "sessions.json"

SCHEMA = 2
SHELL = "/system/bin/sh"


def now():
    return datetime.now(timezone.utc).isoformat()


def ensure_dirs():
    for path in (SESSIONS, LOGS, TASKS, STATE.parent):
        path.mkdir(parents=True, exist_ok=True)


def default_state():
    return {"schema": SCHEMA, "sessions": {}, "tasks": {}}


def load_state():
    ensure_dirs()

    if not STATE.exists():
        return default_state()

    try:
        data = json.loads(STATE.read_text(encoding="utf-8"))

        if not isinstance(data, dict):
            raise ValueError("State root must be an object")

        if data.get("schema") == 1:
            data["schema"] = SCHEMA
            data.setdefault("tasks", {})

            for item in data.get("sessions", {}).values():
                if item.get("status") == "RUNNING":
                    item["status"] = "INTERRUPTED_OR_STALE"
                    item["last_reconciled_at"] = now()

            save_state(data)

        if data.get("schema") != SCHEMA:
            raise ValueError("Unsupported state schema")

        if not isinstance(data.get("sessions"), dict):
            raise ValueError("Invalid sessions database")

        if not isinstance(data.get("tasks"), dict):
            raise ValueError("Invalid tasks database")

        return data

    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(
            "Session state is unreadable; refusing to overwrite it: "
            + str(exc)
        ) from exc


def save_state(data):
    ensure_dirs()
    temporary = STATE.with_name(
        STATE.name + "." + uuid.uuid4().hex + ".tmp"
    )

    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())

        os.replace(temporary, STATE)

    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def log(session_id, message):
    path = LOGS / (session_id + ".log")

    with path.open("a", encoding="utf-8") as handle:
        handle.write(f"[{now()}] {message}\n")
        handle.flush()


def valid_id(value):
    if not isinstance(value, str):
        return False

    if not value or len(value) > 64:
        return False

    return all(ch in "0123456789abcdef-" for ch in value.lower())


def get_session(data, session_id):
    if not valid_id(session_id):
        raise ValueError("Invalid session ID")

    item = data["sessions"].get(session_id)

    if not isinstance(item, dict):
        raise ValueError("Unknown session ID")

    return item


def create_session():
    data = load_state()
    session_id = uuid.uuid4().hex[:12]
    session_dir = SESSIONS / session_id
    session_dir.mkdir(parents=True, exist_ok=False)

    log_path = LOGS / (session_id + ".log")

    item = {
        "id": session_id,
        "created_at": now(),
        "updated_at": now(),
        "status": "READY",
        "cwd": str(ROOT),
        "log_file": str(log_path),
        "history": [],
        "last_exit_code": None,
        "session_type": "logical",
        "interactive_shell_persistent": False,
    }

    data["sessions"][session_id] = item

    try:
        save_state(data)
        log(session_id, "Logical session created")
    except Exception:
        try:
            session_dir.rmdir()
        except OSError:
            pass
        raise

    print("Session ID:", session_id)
    print("Status: READY")
    print("Working directory:", item["cwd"])
    print("Log:", log_path)
    print("Session type: logical; each command uses a new shell process")
    print("Interactive shell state persistence: NOT IMPLEMENTED")


def reconcile_task(task):
    pid = task.get("pid")

    if not isinstance(pid, int) or pid <= 0:
        if task.get("status") == "RUNNING":
            task["status"] = "PID_UNAVAILABLE"
            task["updated_at"] = now()
        return

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        if task.get("status") == "RUNNING":
            task["status"] = "PROCESS_NOT_FOUND"
            task["updated_at"] = now()
    except PermissionError:
        task["status"] = "STATUS_UNCONFIRMED"
        task["updated_at"] = now()


def list_sessions():
    data = load_state()

    if not data["sessions"]:
        print("No registered sessions.")
    else:
        for sid, item in data["sessions"].items():
            print(
                f'{sid} | STATUS={item.get("status")} | '
                f'CWD={item.get("cwd")} | '
                f'LAST_EXIT={item.get("last_exit_code")}'
            )

    changed = False

    for task in data["tasks"].values():
        before = task.get("status")
        reconcile_task(task)
        changed = changed or before != task.get("status")

    if changed:
        save_state(data)

    if data["tasks"]:
        print("\nBACKGROUND TASKS")
        for tid, task in data["tasks"].items():
            print(
                f'{tid} | PID={task.get("pid")} | '
                f'STATUS={task.get("status")} | '
                f'SESSION={task.get("session_id")}'
            )


def run_command(session_id, command, timeout=120):
    if not isinstance(command, str) or not command.strip():
        raise ValueError("Command must not be empty")

    if len(command) > 20000:
        raise ValueError("Command exceeds 20000 characters")

    if timeout < 1 or timeout > 86400:
        raise ValueError("Timeout must be between 1 and 86400 seconds")

    data = load_state()
    item = get_session(data, session_id)

    if item.get("status") == "CLOSED":
        raise RuntimeError("Session is closed")

    cwd = Path(item.get("cwd", str(ROOT))).resolve()

    if not cwd.is_dir():
        cwd = ROOT.resolve()

    if not cwd.is_dir():
        raise RuntimeError("Session working directory is unavailable")

    command_id = uuid.uuid4().hex[:12]
    marker = "__BOSS_RESULT_" + uuid.uuid4().hex + "__"

    # The marker reports exit status and final working directory.
    # The user command is intentionally run through Android's system shell.
    script = (
        command
        + "\n__boss_rc=$?\n"
        + "printf '\\n"
        + marker
        + ":%s:%s\\n' \"$__boss_rc\" \"$PWD\"\n"
    )

    history_item = {
        "id": command_id,
        "command": command,
        "started_at": now(),
        "cwd_before": str(cwd),
        "status": "RUNNING",
    }

    item.setdefault("history", []).append(history_item)
    item["updated_at"] = now()
    save_state(data)

    log(session_id, f"COMMAND START id={command_id} cwd={cwd}")
    log(session_id, "COMMAND TEXT: " + command)

    try:
        result = subprocess.run(
            [SHELL, "-c", script],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )

        output = result.stdout or ""
        errors = result.stderr or ""
        final_cwd = str(cwd)
        exit_code = result.returncode

        marker_prefix = "\n" + marker + ":"
        marker_index = output.rfind(marker_prefix)

        if marker_index >= 0:
            metadata = output[marker_index + len(marker_prefix):].strip()
            pieces = metadata.split(":", 1)

            try:
                exit_code = int(pieces[0])
            except (ValueError, IndexError):
                exit_code = result.returncode

            if len(pieces) == 2:
                candidate = Path(pieces[1])

                try:
                    candidate = candidate.resolve()
                    if candidate.is_dir():
                        final_cwd = str(candidate)
                except OSError:
                    pass

            output = output[:marker_index]

        elif result.returncode == 0:
            # Missing marker means the shell may have exited early.
            exit_code = 125
            errors += "\n[BOSS] Shell ended before result metadata was returned.\n"

        if output:
            print(output, end="" if output.endswith("\n") else "\n")

        if errors:
            print(errors, file=sys.stderr, end="")

        data = load_state()
        item = get_session(data, session_id)
        history_item = next(
            h for h in reversed(item["history"]) if h["id"] == command_id
        )

        history_item["status"] = "COMPLETED"
        history_item["exit_code"] = exit_code
        history_item["finished_at"] = now()
        history_item["cwd_after"] = final_cwd

        item["cwd"] = final_cwd
        item["last_exit_code"] = exit_code
        item["updated_at"] = now()
        save_state(data)

        if output:
            log(session_id, "STDOUT:\n" + output.rstrip())
        if errors:
            log(session_id, "STDERR:\n" + errors.rstrip())

        log(session_id, f"COMMAND END id={command_id} exit_code={exit_code}")
        print(f"\n[BOSS] Exit code: {exit_code}")
        print(f"[BOSS] Working directory: {final_cwd}")
        return exit_code

    except subprocess.TimeoutExpired as exc:
        partial_out = exc.stdout or ""
        partial_err = exc.stderr or ""

        if isinstance(partial_out, bytes):
            partial_out = partial_out.decode("utf-8", "replace")
        if isinstance(partial_err, bytes):
            partial_err = partial_err.decode("utf-8", "replace")

        log(session_id, f"COMMAND TIMEOUT id={command_id} timeout={timeout}")
        if partial_out:
            log(session_id, "PARTIAL STDOUT:\n" + partial_out)
        if partial_err:
            log(session_id, "PARTIAL STDERR:\n" + partial_err)

        data = load_state()
        item = get_session(data, session_id)

        history_item = next(
            h for h in reversed(item["history"]) if h["id"] == command_id
        )
        history_item["status"] = "TIMEOUT"
        history_item["finished_at"] = now()
        history_item["timeout_seconds"] = timeout
        item["updated_at"] = now()
        save_state(data)

        print(f"[BOSS] Command timed out after {timeout} seconds.")
        return 124


def show_logs(session_id, lines=40):
    if lines < 1 or lines > 10000:
        raise ValueError("Lines must be between 1 and 10000")

    data = load_state()
    item = get_session(data, session_id)
    path = Path(item["log_file"])

    if not path.is_file():
        print("Log file not found.")
        return

    content = path.read_text(
        encoding="utf-8", errors="replace"
    ).splitlines()

    for line in content[-lines:]:
        print(line)


def show_history(session_id, limit=100):
    if limit < 1 or limit > 10000:
        raise ValueError("Limit must be between 1 and 10000")

    data = load_state()
    item = get_session(data, session_id)

    for entry in item.get("history", [])[-limit:]:
        print(
            f'{entry.get("id")} | {entry.get("status")} | '
            f'exit={entry.get("exit_code")} | {entry.get("command")}'
        )


def close_session(session_id):
    data = load_state()
    item = get_session(data, session_id)

    # Stop tasks owned by this session before closing its record.
    for task in data["tasks"].values():
        if task.get("session_id") != session_id:
            continue

        reconcile_task(task)

        if task.get("status") == "RUNNING":
            try:
                os.kill(task["pid"], signal.SIGTERM)
                task["status"] = "STOP_REQUESTED"
                task["updated_at"] = now()
            except ProcessLookupError:
                task["status"] = "PROCESS_NOT_FOUND"

    item["status"] = "CLOSED"
    item["closed_at"] = now()
    item["updated_at"] = now()
    save_state(data)
    log(session_id, "Session closed; owned running tasks received stop request")
    print("Session marked CLOSED:", session_id)


def start_task(session_id, command):
    if not command.strip():
        raise ValueError("Task command must not be empty")

    data = load_state()
    item = get_session(data, session_id)

    if item.get("status") == "CLOSED":
        raise RuntimeError("Cannot start a task in a closed session")

    cwd = Path(item.get("cwd", str(ROOT))).resolve()
    if not cwd.is_dir():
        raise RuntimeError("Session working directory is unavailable")

    task_id = uuid.uuid4().hex[:12]
    output_path = TASKS / (task_id + ".log")

    handle = output_path.open("a", encoding="utf-8")

    try:
        process = subprocess.Popen(
            [SHELL, "-c", command],
            cwd=str(cwd),
            stdin=subprocess.DEVNULL,
            stdout=handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
    finally:
        handle.close()

    task = {
        "id": task_id,
        "session_id": session_id,
        "pid": process.pid,
        "command": command,
        "cwd": str(cwd),
        "log_file": str(output_path),
        "created_at": now(),
        "updated_at": now(),
        "status": "RUNNING",
        "background_guarantee": False,
    }

    data["tasks"][task_id] = task

    try:
        save_state(data)
        log(session_id, f"BACKGROUND TASK START id={task_id} pid={process.pid}")
    except Exception:
        try:
            os.kill(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        raise

    print("Task ID:", task_id)
    print("PID:", process.pid)
    print("Status: RUNNING (initial)")
    print("Log:", output_path)
    print("Android background survival: NOT GUARANTEED")


def stop_task(task_id):
    data = load_state()

    if not valid_id(task_id) or task_id not in data["tasks"]:
        raise ValueError("Unknown task ID")

    task = data["tasks"][task_id]
    reconcile_task(task)

    if task.get("status") != "RUNNING":
        save_state(data)
        print("Task is not confirmed running:", task.get("status"))
        return

    try:
        os.kill(task["pid"], signal.SIGTERM)
        task["status"] = "STOP_REQUESTED"
        task["updated_at"] = now()
        save_state(data)
        print("Stop requested:", task_id)
    except ProcessLookupError:
        task["status"] = "PROCESS_NOT_FOUND"
        task["updated_at"] = now()
        save_state(data)
        print("Process was already absent:", task_id)


def task_logs(task_id, lines=40):
    data = load_state()

    if not valid_id(task_id) or task_id not in data["tasks"]:
        raise ValueError("Unknown task ID")

    if lines < 1 or lines > 10000:
        raise ValueError("Lines must be between 1 and 10000")

    path = Path(data["tasks"][task_id]["log_file"])

    if not path.is_file():
        print("Task log not found.")
        return

    for line in path.read_text(
        encoding="utf-8", errors="replace"
    ).splitlines()[-lines:]:
        print(line)


def main():
    parser = argparse.ArgumentParser(
        description="BOSS Dev Engine Terminal Manager v0.2.0"
    )
    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser("start")
    commands.add_parser("list")

    run = commands.add_parser("run")
    run.add_argument("session_id")
    run.add_argument("shell_command")
    run.add_argument("--timeout", type=int, default=120)

    logs = commands.add_parser("logs")
    logs.add_argument("session_id")
    logs.add_argument("--lines", type=int, default=40)

    history = commands.add_parser("history")
    history.add_argument("session_id")
    history.add_argument("--limit", type=int, default=100)

    close = commands.add_parser("close")
    close.add_argument("session_id")

    task_start_parser = commands.add_parser("task-start")
    task_start_parser.add_argument("session_id")
    task_start_parser.add_argument("shell_command")

    task_stop_parser = commands.add_parser("task-stop")
    task_stop_parser.add_argument("task_id")

    task_logs_parser = commands.add_parser("task-logs")
    task_logs_parser.add_argument("task_id")
    task_logs_parser.add_argument("--lines", type=int, default=40)

    args = parser.parse_args()

    try:
        if args.command == "start":
            create_session()
        elif args.command == "list":
            list_sessions()
        elif args.command == "run":
            sys.exit(run_command(
                args.session_id, args.shell_command, args.timeout
            ))
        elif args.command == "logs":
            show_logs(args.session_id, args.lines)
        elif args.command == "history":
            show_history(args.session_id, args.limit)
        elif args.command == "close":
            close_session(args.session_id)
        elif args.command == "task-start":
            start_task(args.session_id, args.shell_command)
        elif args.command == "task-stop":
            stop_task(args.task_id)
        elif args.command == "task-logs":
            task_logs(args.task_id, args.lines)

    except (ValueError, RuntimeError, OSError) as exc:
        print("ERROR:", str(exc), file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
