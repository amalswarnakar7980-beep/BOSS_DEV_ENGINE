#!/system/bin/sh

PROJECT="/storage/emulated/0/BOSS_DEV_ENGINE"
REPORT="$PROJECT/audit/missing_tools_report.txt"

mkdir -p "$PROJECT/audit" "$PROJECT/logs" "$PROJECT/tools/bootstrap"

{
    echo "BOSS DEV ENGINE - MISSING TOOL AUDIT"
    echo "Date: $(date)"
    echo "Project: $PROJECT"
    echo "Architecture: $(getprop ro.product.cpu.abi)"
    echo "Android: $(getprop ro.build.version.release)"
    echo "SDK: $(getprop ro.build.version.sdk)"
    echo

    for tool in java javac gradle git make gcc clang curl wget tar unzip; do
        if command -v "$tool" >/dev/null 2>&1; then
            echo "FOUND: $tool -> $(command -v "$tool")"
        else
            echo "MISSING: $tool"
        fi
    done

    echo
    echo "=== Python ==="
    python --version 2>&1
    python -m pip --version 2>&1

    echo
    echo "=== Environment ==="
    echo "HOME=${HOME:-NOT_SET}"
    echo "PREFIX=${PREFIX:-NOT_SET}"
    echo "ANDROID_HOME=${ANDROID_HOME:-NOT_SET}"
    echo "ANDROID_SDK_ROOT=${ANDROID_SDK_ROOT:-NOT_SET}"
    echo "JAVA_HOME=${JAVA_HOME:-NOT_SET}"

    echo
    echo "=== Storage ==="
    df -h "$PROJECT" 2>&1
} > "$REPORT"

cat "$REPORT"
echo
echo "REPORT SAVED: $REPORT"
