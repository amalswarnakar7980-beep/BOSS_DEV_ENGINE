#!/usr/bin/env python3
"""Bundled isolated regression tests for BOSS terminal manager."""

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
SOURCE = ROOT / "terminal" / "session_manager.py"

spec = importlib.util.spec_from_file_location("boss_terminal_manager", SOURCE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

passed = 0
failed = 0


def check(name, fn):
    global passed, failed
    try:
        fn()
        passed += 1
        print("PASS:", name)
    except Exception as exc:
        failed += 1
        print("FAIL:", name, "-", type(exc).__name__, str(exc))


def isolated():
    temp = tempfile.TemporaryDirectory(prefix="boss_terminal_test_")
    base = Path(temp.name)
    mod.ROOT = base
    mod.BASE = base / "terminal"
    mod.SESSIONS = mod.BASE / "sessions"
    mod.LOGS = mod.BASE / "logs"
    mod.TASKS = mod.BASE / "tasks"
    mod.STATE = mod.BASE / "state" / "sessions.json"
    mod.ensure_dirs()
    return temp, base


temp, base = isolated()
session_id = None


def test_create_session():
    global session_id
    # Capture printed output is unnecessary: read durable state directly.
    data = mod.load_state()
    session_id = "deadbeef0001"
    data["sessions"][session_id] = {
        "id": session_id,
        "created_at": mod.now(),
        "updated_at": mod.now(),
        "status": "READY",
        "cwd": str(base),
        "log_file": str(mod.LOGS / (session_id + ".log")),
        "history": [],
        "last_exit_code": None,
        "session_type": "logical",
        "interactive_shell_persistent": False,
    }
    mod.save_state(data)
    assert mod.load_state()["sessions"][session_id]["status"] == "READY"


def test_command_output_and_exit():
    rc = mod.run_command(session_id, "printf 'BOSS_OUTPUT_OK'")
    assert rc == 0
    text = (mod.LOGS / (session_id + ".log")).read_text()
    assert "BOSS_OUTPUT_OK" in text
    data = mod.load_state()
    assert data["sessions"][session_id]["last_exit_code"] == 0


def test_working_directory_restore():
    target = base / "workdir"
    target.mkdir()
    rc = mod.run_command(session_id, "cd " + str(target))
    assert rc == 0
    data = mod.load_state()
    assert data["sessions"][session_id]["cwd"] == str(target.resolve())


def test_history_persists():
    data = mod.load_state()
    history = data["sessions"][session_id]["history"]
    assert len(history) >= 2
    assert any("printf" in item["command"] for item in history)


def test_nonzero_exit_code():
    rc = mod.run_command(session_id, "exit 7")
    assert rc != 0
    data = mod.load_state()
    assert data["sessions"][session_id]["last_exit_code"] != 0


def test_closed_session_rejects_commands():
    mod.close_session(session_id)
    try:
        mod.run_command(session_id, "echo should-not-run")
    except RuntimeError:
        return
    raise AssertionError("Closed session accepted a command")


def test_corrupt_state_is_not_overwritten():
    original = mod.STATE.read_text(encoding="utf-8")
    mod.STATE.write_text("{bad json", encoding="utf-8")
    try:
        mod.load_state()
    except RuntimeError:
        pass
    else:
        raise AssertionError("Corrupt state was accepted")
    assert mod.STATE.read_text(encoding="utf-8") == "{bad json"
    mod.STATE.write_text(original, encoding="utf-8")


def test_task_tracking_and_stop():
    data = mod.load_state()
    item = data["sessions"][session_id]
    item["status"] = "READY"
    mod.save_state(data)

    mod.start_task(session_id, "sleep 30")
    data = mod.load_state()
    task_ids = list(data["tasks"])
    assert task_ids
    task_id = task_ids[-1]
    assert data["tasks"][task_id]["status"] == "RUNNING"
    mod.stop_task(task_id)

    deadline = time.time() + 3
    while time.time() < deadline:
        data = mod.load_state()
        mod.reconcile_task(data["tasks"][task_id])
        if data["tasks"][task_id]["status"] != "RUNNING":
            break
        time.sleep(0.1)

    data = mod.load_state()
    assert data["tasks"][task_id]["status"] in (
        "STOP_REQUESTED", "PROCESS_NOT_FOUND", "STATUS_UNCONFIRMED"
    )


def test_unknown_session_rejected():
    try:
        mod.run_command("000000000000", "echo nope")
    except ValueError:
        return
    raise AssertionError("Unknown session accepted")


def test_invalid_timeout_rejected():
    try:
        mod.run_command(session_id, "echo nope", timeout=0)
    except ValueError:
        return
    raise AssertionError("Invalid timeout accepted")


tests = [
    ("Session state creation and persistence", test_create_session),
    ("Command output, log persistence and exit code", test_command_output_and_exit),
    ("Working directory restoration between commands", test_working_directory_restore),
    ("Command history persistence", test_history_persists),
    ("Non-zero command exit status", test_nonzero_exit_code),
    ("Closed session rejects commands", test_closed_session_rejects_commands),
    ("Corrupt state is preserved, not overwritten", test_corrupt_state_is_not_overwritten),
    ("Background task tracking and stop request", test_task_tracking_and_stop),
    ("Unknown session rejection", test_unknown_session_rejected),
    ("Invalid timeout rejection", test_invalid_timeout_rejected),
]

print("=" * 68)
print("BOSS DEV ENGINE — TERMINAL ENGINE REGRESSION BUNDLE")
print("Isolated test directory:", base)
print("=" * 68)

for name, fn in tests:
    check(name, fn)

temp.cleanup()

print("=" * 68)
print("PASS:", passed)
print("FAIL:", failed)
print("OVERALL:", "PASS" if failed == 0 else "FAIL")
print("=" * 68)

sys.exit(1 if failed else 0)
