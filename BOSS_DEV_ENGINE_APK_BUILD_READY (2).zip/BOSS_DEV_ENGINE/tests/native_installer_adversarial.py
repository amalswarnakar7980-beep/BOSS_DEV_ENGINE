import contextlib
import hashlib
import importlib.util
import io
import json
import tempfile
import warnings
import zipfile

from pathlib import Path


SOURCE = Path(
    "/storage/emulated/0/BOSS_DEV_ENGINE/"
    "packages/manager/native_installer.py"
)

spec = importlib.util.spec_from_file_location(
    "boss_native_installer_under_test", SOURCE
)
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


def make_archive(cache, name, entries, declared=None):
    """
    entries: list of (ZIP member name, bytes)
    declared: list of (relative target path, expected SHA256)
    """
    archive_path = cache / f"{name}.zip"

    if declared is None:
        payloads = [
            (member[len("payload/"):], content)
            for member, content in entries
            if member.startswith("payload/")
        ]
        declared = [
            (path, hashlib.sha256(content).hexdigest())
            for path, content in payloads
        ]

    manifest = {
        "name": name,
        "version": "1.0.0",
        "files": [
            {"path": path, "sha256": digest}
            for path, digest in declared
        ],
    }

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(
            archive_path, "w", zipfile.ZIP_DEFLATED
        ) as archive:
            archive.writestr(
                "manifest.json",
                json.dumps(manifest),
            )
            for member, content in entries:
                archive.writestr(member, content)

    return archive_path


def configure_isolated(root):
    base = root / "packages"
    installer.ROOT = root
    installer.BASE = base
    installer.CACHE = base / "cache"
    installer.ROOTFS = base / "rootfs"
    installer.INSTALLED = base / "installed"
    installer.LOGS = base / "logs"
    installer.DB = installer.INSTALLED / "native_packages.json"
    installer.LOG = installer.LOGS / "native_installer.jsonl"

    for path in (
        installer.CACHE,
        installer.ROOTFS,
        installer.INSTALLED,
        installer.LOGS,
    ):
        path.mkdir(parents=True, exist_ok=True)


def empty_db():
    if not installer.DB.exists():
        return {"schema": 1, "packages": {}}
    return json.loads(installer.DB.read_text())


def expect_rejection(label, archive):
    before = empty_db()
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            installer.install(archive)
    except Exception as exc:
        after = empty_db()
        assert after == before, (
            f"database changed after rejected archive: {after}"
        )
        print(f"PASS: {label} rejected ({type(exc).__name__})")
    else:
        raise AssertionError(f"{label} was unexpectedly accepted")


with tempfile.TemporaryDirectory(
    prefix="boss_native_audit_"
) as temporary:
    temp_root = Path(temporary)
    configure_isolated(temp_root)

    # 1. Wrong SHA-256
    archive = make_archive(
        installer.CACHE,
        "wrong-hash",
        [("payload/share/wrong.txt", b"safe content")],
        [("share/wrong.txt", "0" * 64)],
    )
    expect_rejection("wrong SHA-256", archive)
    assert not (
        installer.ROOTFS / "share/wrong.txt"
    ).exists()
    print("PASS: wrong hash left no target file")

    # 2. Manifest path traversal
    archive = make_archive(
        installer.CACHE,
        "traversal",
        [("payload/share/traversal.txt", b"test")],
        [("../outside.txt", hashlib.sha256(b"test").hexdigest())],
    )
    expect_rejection("manifest path traversal", archive)
    assert not (temp_root / "outside.txt").exists()
    print("PASS: traversal wrote no outside file")

    # 3. Duplicate ZIP member
    archive = installer.CACHE / "duplicate.zip"
    content = b"duplicate test"
    manifest = {
        "name": "duplicate",
        "version": "1.0.0",
        "files": [{
            "path": "share/duplicate.txt",
            "sha256": hashlib.sha256(content).hexdigest(),
        }],
    }
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(archive, "w") as z:
            z.writestr("manifest.json", json.dumps(manifest))
            z.writestr("payload/share/duplicate.txt", content)
            z.writestr("payload/share/duplicate.txt", content + b"x")
    expect_rejection("duplicate ZIP member", archive)

    # 4. Unexpected payload entry
    archive = make_archive(
        installer.CACHE,
        "unexpected",
        [
            ("payload/share/expected.txt", b"expected"),
            ("payload/share/extra.txt", b"unexpected"),
        ],
        [(
            "share/expected.txt",
            hashlib.sha256(b"expected").hexdigest(),
        )],
    )
    expect_rejection("unexpected payload entry", archive)

    # 5. Existing file must not be overwritten
    existing = installer.ROOTFS / "share" / "keep.txt"
    existing.parent.mkdir(parents=True, exist_ok=True)
    existing.write_bytes(b"ORIGINAL")
    archive = make_archive(
        installer.CACHE,
        "overwrite",
        [("payload/share/keep.txt", b"REPLACEMENT")],
    )
    expect_rejection("existing-file overwrite", archive)
    assert existing.read_bytes() == b"ORIGINAL"
    print("PASS: existing file content preserved")

    # 6. Install database-save failure should roll back files
    archive = make_archive(
        installer.CACHE,
        "save-fail-install",
        [("payload/share/rollback.txt", b"rollback")],
    )
    original_save = installer.save_db

    def fail_save(_data):
        raise OSError("INJECTED_DATABASE_SAVE_FAILURE")

    installer.save_db = fail_save
    try:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                installer.install(archive)
        except OSError as exc:
            assert "INJECTED_DATABASE_SAVE_FAILURE" in str(exc)
        else:
            raise AssertionError("injected save failure was not raised")
    finally:
        installer.save_db = original_save

    assert not (
        installer.ROOTFS / "share/rollback.txt"
    ).exists()
    assert "save-fail-install" not in empty_db()["packages"]
    print("PASS: install save failure rolled back created file")

    # 7. Uninstall database-save failure consistency test
    archive = make_archive(
        installer.CACHE,
        "save-fail-uninstall",
        [("payload/share/uninstall.txt", b"uninstall test")],
    )
    with contextlib.redirect_stdout(io.StringIO()):
        installer.install(archive)

    target = installer.ROOTFS / "share/uninstall.txt"
    assert target.exists()
    assert "save-fail-uninstall" in empty_db()["packages"]

    installer.save_db = fail_save
    try:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                installer.uninstall("save-fail-uninstall")
        except OSError as exc:
            assert "INJECTED_DATABASE_SAVE_FAILURE" in str(exc)
        else:
            raise AssertionError("uninstall save failure was not raised")
    finally:
        installer.save_db = original_save

    record_exists = (
        "save-fail-uninstall" in empty_db()["packages"]
    )
    file_exists = target.exists()

    assert record_exists, (
        "Uninstall rollback failed: package database record is missing"
    )
    assert file_exists, (
        "Uninstall rollback failed: installed file was not restored"
    )
    assert target.read_bytes() == b"uninstall test", (
        "Uninstall rollback failed: installed file content changed"
    )
    print(
        "PASS: uninstall database-save failure preserved package record "
        "and restored original file"
    )

    print("ISOLATED ADVERSARIAL AUDIT FINISHED")
    print("Temporary test files will now be removed.")
