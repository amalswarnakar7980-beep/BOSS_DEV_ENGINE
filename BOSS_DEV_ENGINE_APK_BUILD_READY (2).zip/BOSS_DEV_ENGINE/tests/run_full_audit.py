import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
REPORT = ROOT / "audit" / "full_audit_report.json"

results = []


def run_test(name, command, timeout=120):
    print("\n" + "=" * 65)
    print("TEST:", name)
    print("COMMAND:", " ".join(map(str, command)))
    print("-" * 65)

    started = time.time()

    try:
        process = subprocess.run(
            list(map(str, command)),
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        output = process.stdout or ""
        errors = process.stderr or ""

        if output:
            print(output.rstrip())

        if errors:
            print("STDERR:")
            print(errors.rstrip())

        result = {
            "test": name,
            "exit_code": process.returncode,
            "duration_seconds": round(time.time() - started, 3),
            "stdout": output[-12000:],
            "stderr": errors[-6000:],
            "status": "PASS" if process.returncode == 0 else "FAIL",
        }

    except subprocess.TimeoutExpired as exc:
        result = {
            "test": name,
            "status": "FAIL",
            "error": "TIMEOUT",
            "duration_seconds": round(time.time() - started, 3),
            "stdout": str(exc.stdout or "")[-4000:],
            "stderr": str(exc.stderr or "")[-4000:],
        }

    except Exception as exc:
        result = {
            "test": name,
            "status": "FAIL",
            "error": f"{type(exc).__name__}: {exc}",
        }

    results.append(result)
    print("RESULT:", result["status"])
    return result["status"] == "PASS"


print("=" * 65)
print("BOSS DEV ENGINE — FULL AUDIT BUNDLE")
print("Project:", ROOT)
print("=" * 65)

# 1. Compile every project Python source file, excluding generated/cache files.
sources = sorted(
    path for path in ROOT.rglob("*.py")
    if "__pycache__" not in path.parts
    and not any(part.startswith(".") for part in path.parts)
    and "boss_uninstall_rollback_" not in str(path)
)

print("\nSOURCE FILES FOUND:", len(sources))

if not sources:
    results.append({
        "test": "Python source inventory",
        "status": "FAIL",
        "error": "No Python source files found",
    })
else:
    compile_result = run_test(
        "Compile all Python sources",
        [
            sys.executable, "-m", "py_compile",
            *sources,
        ],
        timeout=180,
    )

# 2. Run the consolidated installer adversarial suite.
suite = ROOT / "tests" / "native_installer_adversarial.py"

if suite.is_file():
    run_test(
        "Native installer adversarial regression",
        [sys.executable, suite],
        timeout=180,
    )
else:
    results.append({
        "test": "Native installer adversarial regression",
        "status": "BLOCKED",
        "error": "Test suite not found",
    })

# 3. CLI contract checks.
cli_checks = [
    (
        "Native installer CLI",
        [sys.executable, "packages/manager/native_installer.py", "--help"],
    ),
    (
        "Native package manager status",
        [sys.executable, "packages/manager/boss_pkg.py", "status"],
    ),
    (
        "Repository manager status",
        [sys.executable, "packages/manager/repository_manager.py", "status"],
    ),
    (
        "Native installer package listing",
        [sys.executable, "packages/manager/native_installer.py", "list"],
    ),
    (
        "Terminal session inventory",
        [sys.executable, "terminal/session_manager.py", "list"],
    ),
]

for name, command in cli_checks:
    run_test(name, command, timeout=60)

# 4. Evidence inventory. Inventory itself does not imply PASS.
inventory = {}

for label, relative in [
    ("requirements", "config/runtime_requirements.json"),
    ("terminal_state", "terminal/state/sessions.json"),
    ("installer_database", "packages/installed/native_packages.json"),
    ("installer_log", "packages/logs/native_installer.jsonl"),
]:
    path = ROOT / relative

    if path.is_file():
        try:
            inventory[label] = {
                "exists": True,
                "bytes": path.stat().st_size,
                "json_valid": None,
            }

            if path.suffix == ".json":
                try:
                    json.loads(path.read_text(encoding="utf-8"))
                    inventory[label]["json_valid"] = True
                except Exception as exc:
                    inventory[label]["json_valid"] = False
                    inventory[label]["json_error"] = str(exc)

        except OSError as exc:
            inventory[label] = {
                "exists": True,
                "error": str(exc),
            }
    else:
        inventory[label] = {"exists": False}

# Do not count diagnostic/blocked checks as successful implementation.
counts = {
    "PASS": sum(item.get("status") == "PASS" for item in results),
    "FAIL": sum(item.get("status") == "FAIL" for item in results),
    "BLOCKED": sum(item.get("status") == "BLOCKED" for item in results),
}

report = {
    "project": "BOSS_DEV_ENGINE",
    "audit": "FULL_AUDIT_BUNDLE",
    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    "summary": counts,
    "overall": (
        "PASS"
        if counts["FAIL"] == 0
        and counts["BLOCKED"] == 0
        else "FAIL_OR_BLOCKED"
    ),
    "python_source_count": len(sources),
    "inventory": inventory,
    "results": results,
}

REPORT.write_text(
    json.dumps(report, indent=2),
    encoding="utf-8",
)

print("\n" + "=" * 65)
print("FULL AUDIT SUMMARY")
print("=" * 65)
print("PASS:", counts["PASS"])
print("FAIL:", counts["FAIL"])
print("BLOCKED:", counts["BLOCKED"])
print("OVERALL:", report["overall"])
print("REPORT:", REPORT)

for item in results:
    print(f'{item.get("status", "UNKNOWN"):8} {item["test"]}')

print("=" * 65)

sys.exit(1 if report["overall"] != "PASS" else 0)
