import json
import os
import platform
import shutil
import ssl
import sys
import tarfile
import urllib.request
from pathlib import Path

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
OUT = ROOT / "audit" / "native_runtime_probe.json"
OUT.parent.mkdir(parents=True, exist_ok=True)

results = {
    "python_version": sys.version.split()[0],
    "architecture": platform.machine(),
    "android_linux_platform": platform.platform(),
    "checks": {},
}

def check(name, function):
    try:
        value = function()
        results["checks"][name] = {
            "status": "PASS",
            "detail": str(value),
        }
    except Exception as exc:
        results["checks"][name] = {
            "status": "FAIL",
            "detail": f"{type(exc).__name__}: {exc}",
        }

def check_storage():
    path = ROOT / "packages" / "cache" / "probe.tmp"
    path.write_text("BOSS_RUNTIME_PROBE", encoding="utf-8")
    value = path.read_text(encoding="utf-8")
    path.unlink()
    if value != "BOSS_RUNTIME_PROBE":
        raise RuntimeError("Storage read-back mismatch")
    return "Write/read/delete succeeded"

def check_tls():
    context = ssl.create_default_context()
    return f"TLS context created; OpenSSL={ssl.OPENSSL_VERSION}"

def check_archive():
    path = ROOT / "packages" / "cache" / "probe.tar"
    with tarfile.open(path, "w") as archive:
        source = ROOT / "packages" / "cache" / "probe.txt"
        source.write_text("archive-test", encoding="utf-8")
        archive.add(source, arcname="probe.txt")
        source.unlink()

    with tarfile.open(path, "r") as archive:
        names = archive.getnames()

    path.unlink()
    if names != ["probe.txt"]:
        raise RuntimeError(f"Unexpected archive contents: {names}")
    return "tar create/read succeeded"

def check_executable_permission():
    path = ROOT / "packages" / "cache" / "permission_probe.sh"
    path.write_text("#!/system/bin/sh\nexit 0\n", encoding="utf-8")
    path.chmod(0o700)
    mode = oct(path.stat().st_mode & 0o777)
    path.unlink()
    return f"chmod accepted; reported mode={mode}; execution NOT tested"

def check_download_library():
    request = urllib.request.Request(
        "https://example.com/",
        headers={"User-Agent": "BOSS-Dev-Engine/0.1"},
        method="HEAD",
    )
    with urllib.request.urlopen(request, timeout=8) as response:
        return f"HTTPS request succeeded; HTTP status={response.status}"

check("project_storage", check_storage)
check("tls_context", check_tls)
check("python_tar_archive", check_archive)
check("executable_permission_metadata", check_executable_permission)
check("https_network", check_download_library)

for name in ("tar", "unzip", "gcc", "make", "git", "curl", "wget",
             "clang", "java", "gradle", "node", "npm", "proot"):
    results["checks"]["command:" + name] = {
        "status": "FOUND" if shutil.which(name) else "MISSING",
        "detail": shutil.which(name) or "Not found on PATH",
    }

OUT.write_text(json.dumps(results, indent=2), encoding="utf-8")

print("=== BOSS NATIVE RUNTIME PROBE ===")
for name, result in results["checks"].items():
    print(f'{result["status"]}: {name} - {result["detail"]}')
print("\nReport saved:", OUT)
print("\nNOTE: HTTPS success does not prove native package compatibility.")
print("NOTE: chmod success does not prove Android will execute a binary.")
