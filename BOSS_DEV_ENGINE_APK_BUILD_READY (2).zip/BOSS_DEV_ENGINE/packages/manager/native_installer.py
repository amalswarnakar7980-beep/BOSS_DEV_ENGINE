#!/usr/bin/env python3

"""
BOSS Dev Engine Native Package Installer
Version: 0.1.0

Installs verified files from local ZIP packages into BOSS rootfs.
This is an initial installer, not a complete Linux package manager.
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import zipfile

from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
BASE = ROOT / "packages"
CACHE = BASE / "cache"
ROOTFS = BASE / "rootfs"
INSTALLED = BASE / "installed"
LOGS = BASE / "logs"

DB = INSTALLED / "native_packages.json"
LOG = LOGS / "native_installer.jsonl"

MAX_ARCHIVE_SIZE = 100 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED = 256 * 1024 * 1024
MAX_FILE_SIZE = 64 * 1024 * 1024
MAX_FILES = 2000

for directory in (CACHE, ROOTFS, INSTALLED, LOGS):
    directory.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.now(timezone.utc).isoformat()


def log(action, details):
    record = {
        "time": now(),
        "action": action,
        "details": details,
    }

    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record) + "\n")


def load_db():
    if not DB.exists():
        return {"schema": 1, "packages": {}}

    try:
        data = json.loads(DB.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(
            f"Package database is unreadable: {exc}"
        ) from exc

    if data.get("schema") != 1:
        raise RuntimeError("Unsupported package database schema")

    if not isinstance(data.get("packages"), dict):
        raise RuntimeError("Invalid package database")

    return data


def save_db(data):
    temporary = DB.with_suffix(".tmp")

    temporary.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8",
    )

    temporary.replace(DB)


def validate_name(name):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{0,79}", name):
        raise ValueError("Invalid package name")


def safe_relative_path(value):
    if not isinstance(value, str) or not value:
        raise ValueError("Empty or invalid package path")

    if "\\" in value or "\x00" in value:
        raise ValueError(f"Invalid path: {value!r}")

    path = PurePosixPath(value)

    if path.is_absolute():
        raise ValueError(f"Absolute paths are forbidden: {value}")

    if any(part in ("", ".", "..") for part in value.split("/")):
        raise ValueError(f"Unsafe package path: {value}")

    if path.parts[0] in (".", ".."):
        raise ValueError(f"Unsafe package path: {value}")

    return path


def sha256_file(path):
    digest = hashlib.sha256()

    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)

    return digest.hexdigest()


def check_archive_member(info):
    name = info.filename

    if not name or "\\" in name or "\x00" in name:
        raise ValueError(f"Invalid ZIP member: {name!r}")

    path = PurePosixPath(name)

    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"ZIP path traversal blocked: {name}")

    # Reject symbolic links and other special Unix file types.
    mode = (info.external_attr >> 16) & 0xFFFF
    kind = stat.S_IFMT(mode)

    if kind not in (0, stat.S_IFREG, stat.S_IFDIR):
        raise ValueError(f"Special files are forbidden: {name}")

    if info.file_size > MAX_FILE_SIZE:
        raise ValueError(f"Package file too large: {name}")

    if info.flag_bits & 0x1:
        raise ValueError("Encrypted ZIP members are not supported")

    return path


def install(archive_path):
    archive_path = Path(archive_path).resolve()

    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)

    if archive_path.stat().st_size > MAX_ARCHIVE_SIZE:
        raise ValueError("Package archive exceeds size limit")

    stage = None

    try:
        with zipfile.ZipFile(archive_path, "r") as archive:
            infos = archive.infolist()

            if len(infos) > MAX_FILES + 1:
                raise ValueError("Too many ZIP members")

            names = set()
            total_size = 0

            for info in infos:
                check_archive_member(info)

                if info.filename in names:
                    raise ValueError(
                        f"Duplicate ZIP member: {info.filename}"
                    )

                names.add(info.filename)
                total_size += info.file_size

                if total_size > MAX_TOTAL_UNCOMPRESSED:
                    raise ValueError(
                        "Uncompressed package exceeds size limit"
                    )

            if "manifest.json" not in names:
                raise ValueError("Package manifest is missing")

            manifest_info = archive.getinfo("manifest.json")

            if manifest_info.file_size > 1024 * 1024:
                raise ValueError("Manifest exceeds size limit")

            manifest = json.loads(
                archive.read("manifest.json").decode("utf-8")
            )

            name = manifest.get("name")
            version = manifest.get("version")
            files = manifest.get("files")

            validate_name(name)

            if not isinstance(version, str) or not version:
                raise ValueError("Invalid package version")

            if not isinstance(files, list) or not files:
                raise ValueError("Package file list is empty or invalid")

            if len(files) > MAX_FILES:
                raise ValueError("Too many manifest files")

            db = load_db()

            if name in db["packages"]:
                raise ValueError(
                    f"Package already installed: {name}"
                )

            declared = {}

            for entry in files:
                if not isinstance(entry, dict):
                    raise ValueError("Invalid manifest file entry")

                relative = safe_relative_path(entry.get("path"))
                expected_hash = entry.get("sha256")

                if not re.fullmatch(
                    r"[a-fA-F0-9]{64}",
                    str(expected_hash),
                ):
                    raise ValueError(
                        f"Invalid SHA-256 for {relative}"
                    )

                key = relative.as_posix()

                if key in declared:
                    raise ValueError(
                        f"Duplicate manifest path: {key}"
                    )

                declared[key] = expected_hash.lower()

            expected_members = {
                "payload/" + path for path in declared
            }

            actual_members = {
                item for item in names
                if item.startswith("payload/")
                and not item.endswith("/")
            }

            if actual_members != expected_members:
                raise ValueError(
                    "Archive contents do not match manifest"
                )

            stage = Path(tempfile.mkdtemp(
                prefix="boss_pkg_stage_",
                dir=str(CACHE),
            ))

            staged_files = []

            for relative, expected_hash in declared.items():
                member = "payload/" + relative
                destination = stage.joinpath(*PurePosixPath(relative).parts)

                destination.parent.mkdir(
                    parents=True,
                    exist_ok=True,
                )

                with archive.open(member, "r") as source:
                    with destination.open("xb") as target:
                        shutil.copyfileobj(source, target, 1024 * 1024)

                actual_hash = sha256_file(destination)

                if actual_hash.lower() != expected_hash:
                    raise ValueError(
                        f"SHA-256 mismatch: {relative}"
                    )

                staged_files.append((relative, destination))

        # Preflight all target paths before changing the rootfs.
        targets = []

        for relative, staged in staged_files:
            target = ROOTFS.joinpath(
                *PurePosixPath(relative).parts
            ).resolve()

            root = ROOTFS.resolve()

            if target == root or root not in target.parents:
                raise ValueError(
                    f"Target escapes package root: {relative}"
                )

            if target.exists():
                raise FileExistsError(
                    f"Target already exists; refusing overwrite: {target}"
                )

            targets.append((relative, staged, target))

        created = []

        try:
            for relative, staged, target in targets:
                target.parent.mkdir(parents=True, exist_ok=True)

                if target.exists():
                    raise FileExistsError(target)

                shutil.copy2(staged, target)
                created.append(target)

            db = load_db()

            if name in db["packages"]:
                raise ValueError(
                    "Package was installed concurrently"
                )

            db["packages"][name] = {
                "version": version,
                "files": [relative for relative, _, _ in targets],
                "installed_at": now(),
                "source_archive": archive_path.name,
                "verification": "SHA256_MATCHED",
            }

            save_db(db)

        except Exception:
            for target in reversed(created):
                try:
                    target.unlink(missing_ok=True)
                except OSError:
                    pass
            raise

        log("install", {
            "name": name,
            "version": version,
            "files": len(targets),
            "result": "PASS",
        })

        print(f"INSTALL: PASS")
        print(f"Package: {name}")
        print(f"Version: {version}")
        print(f"Files installed: {len(targets)}")
        print("Integrity: SHA-256 verified")
        print("Execution: NOT TESTED")

    except Exception as exc:
        log("install", {
            "archive": archive_path.name,
            "result": "FAIL",
            "error": str(exc),
        })
        raise

    finally:
        if stage is not None:
            shutil.rmtree(stage, ignore_errors=True)


def list_packages():
    db = load_db()

    if not db["packages"]:
        print("No native packages installed.")
        return

    for name, info in sorted(db["packages"].items()):
        print(f'{name}=={info["version"]}')



def uninstall(name):
    validate_name(name)
    db = load_db()

    if name not in db["packages"]:
        raise ValueError(f"Package is not installed: {name}")

    info = db["packages"][name]
    files = info.get("files", [])

    if not isinstance(files, list):
        raise ValueError("Invalid package file ownership record")

    root = ROOTFS.resolve()
    targets = []

    # Validate every owned path before touching any file.
    for relative in files:
        path = safe_relative_path(relative)
        unresolved = ROOTFS.joinpath(*path.parts)

        # Do not follow a final symlink when determining what to move.
        if unresolved.is_symlink():
            target = unresolved
        else:
            target = unresolved.resolve()

        if target == root or root not in target.parents:
            raise ValueError(f"Unsafe uninstall target: {relative}")

        targets.append((relative, target))

    # Move files to a temporary quarantine first. If the database
    # update fails, restore the moved files before returning failure.
    quarantine = Path(tempfile.mkdtemp(
        prefix="boss_uninstall_rollback_",
        dir=str(CACHE),
    ))

    moved = []
    db_committed = False

    try:
        for relative, target in targets:
            if not (target.is_file() or target.is_symlink()):
                continue

            backup_path = quarantine.joinpath(
                *PurePosixPath(relative).parts
            )
            backup_path.parent.mkdir(parents=True, exist_ok=True)

            os.replace(target, backup_path)
            moved.append((target, backup_path))

        updated = {
            "schema": db["schema"],
            "packages": dict(db["packages"]),
        }
        del updated["packages"][name]

        save_db(updated)
        db_committed = True

    except Exception as exc:
        restore_errors = []

        if not db_committed:
            for original, backup_path in reversed(moved):
                try:
                    original.parent.mkdir(parents=True, exist_ok=True)
                    if backup_path.exists() or backup_path.is_symlink():
                        os.replace(backup_path, original)
                except OSError as restore_exc:
                    restore_errors.append(
                        f"{original}: {restore_exc}"
                    )

        if restore_errors:
            raise RuntimeError(
                "Uninstall failed and rollback was incomplete. "
                "Recovery files may remain in: "
                f"{quarantine}. Details: {'; '.join(restore_errors)}"
            ) from exc

        raise

    finally:
        # On successful commit, quarantine holds only obsolete copies.
        # If rollback left anything behind, preserve it for recovery.
        if db_committed:
            shutil.rmtree(quarantine, ignore_errors=True)
        elif not any(
            backup_path.exists() or backup_path.is_symlink()
            for _, backup_path in moved
        ):
            shutil.rmtree(quarantine, ignore_errors=True)

    log("uninstall", {
        "name": name,
        "files": len(moved),
        "result": "PASS",
    })

    print("UNINSTALL: PASS")
    print("Package:", name)
    print("Owned files removed:", len(moved))
    print("Database consistency: COMMITTED")

def main():
    parser = argparse.ArgumentParser(
        description="BOSS Dev Engine Native Package Installer"
    )

    sub = parser.add_subparsers(dest="command", required=True)

    install_parser = sub.add_parser("install")
    install_parser.add_argument("archive")

    uninstall_parser = sub.add_parser("uninstall")
    uninstall_parser.add_argument("name")

    sub.add_parser("list")

    args = parser.parse_args()

    try:
        if args.command == "install":
            install(args.archive)
        elif args.command == "uninstall":
            uninstall(args.name)
        elif args.command == "list":
            list_packages()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
