#!/usr/bin/env python3

import argparse
import hashlib
import json
import re
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
REPOSITORIES = ROOT / "packages" / "repositories"
CACHE = ROOT / "packages" / "cache"
AUDIT = ROOT / "audit"

for directory in (REPOSITORIES, CACHE, AUDIT):
    directory.mkdir(parents=True, exist_ok=True)

INDEX = REPOSITORIES / "index.json"
LOG = ROOT / "packages" / "logs" / "repository_manager.jsonl"

def log(action, details):
    LOG.parent.mkdir(parents=True, exist_ok=True)
    event = {
        "time": datetime.now(timezone.utc).isoformat(),
        "action": action,
        "details": details,
    }
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event) + "\n")

def load_index():
    if not INDEX.exists():
        return {
            "schema": 1,
            "repositories": [],
            "packages": {},
        }

    data = json.loads(INDEX.read_text(encoding="utf-8"))

    if data.get("schema") != 1:
        raise ValueError("Unsupported repository index schema")

    if not isinstance(data.get("repositories"), list):
        raise ValueError("Invalid repositories list")

    if not isinstance(data.get("packages"), dict):
        raise ValueError("Invalid package catalogue")

    return data

def save_index(data):
    temporary = INDEX.with_suffix(".tmp")
    temporary.write_text(
        json.dumps(data, indent=2),
        encoding="utf-8",
    )
    temporary.replace(INDEX)

def validate_package_name(name):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{0,99}", name):
        raise ValueError("Invalid package name")

def validate_https_url(url):
    parsed = urlparse(url)

    if parsed.scheme != "https" or not parsed.hostname:
        raise ValueError("Only HTTPS URLs are accepted")

    if parsed.username or parsed.password:
        raise ValueError("Credentials in URLs are forbidden")

def add_repository(name, index_url):
    validate_package_name(name)
    validate_https_url(index_url)

    data = load_index()

    if any(item["name"] == name for item in data["repositories"]):
        raise ValueError("Repository name already exists")

    data["repositories"].append({
        "name": name,
        "index_url": index_url,
        "enabled": False,
        "trust_status": "UNVERIFIED",
    })

    save_index(data)

    log("repository_added", {
        "name": name,
        "index_url": index_url,
        "enabled": False,
    })

    print("Repository saved but DISABLED.")
    print("Trust status: UNVERIFIED")
    print("No package is trusted or installable yet.")

def status():
    data = load_index()

    print("BOSS Repository Manager: 0.1.0")
    print("Repositories:", len(data["repositories"]))
    print("Catalogue entries:", len(data["packages"]))

    for repository in data["repositories"]:
        print(
            f'{repository["name"]}: '
            f'enabled={repository["enabled"]}, '
            f'trust={repository["trust_status"]}'
        )

def verify_file(file_path, expected_sha256):
    if not re.fullmatch(r"[a-fA-F0-9]{64}", expected_sha256):
        raise ValueError("Expected SHA-256 must contain 64 hex characters")

    path = Path(file_path).resolve()
    cache_root = CACHE.resolve()

    if path != cache_root and cache_root not in path.parents:
        raise ValueError("File must be inside the package cache")

    if not path.is_file():
        raise FileNotFoundError(path)

    digest = hashlib.sha256()

    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)

    actual = digest.hexdigest()
    passed = actual.lower() == expected_sha256.lower()

    log("sha256_verification", {
        "file": path.name,
        "expected": expected_sha256.lower(),
        "actual": actual,
        "passed": passed,
    })

    print("File:", path.name)
    print("Expected SHA-256:", expected_sha256.lower())
    print("Actual SHA-256:  ", actual)
    print("Result:", "PASS" if passed else "FAIL")

    if not passed:
        raise SystemExit(1)

def main():
    parser = argparse.ArgumentParser(
        description="BOSS trusted repository foundation"
    )

    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser("status")

    add = commands.add_parser("add")
    add.add_argument("name")
    add.add_argument("https_index_url")

    verify = commands.add_parser("verify")
    verify.add_argument("filename")
    verify.add_argument("sha256")

    args = parser.parse_args()

    if args.command == "status":
        status()
    elif args.command == "add":
        add_repository(args.name, args.https_index_url)
    elif args.command == "verify":
        verify_file(args.filename, args.sha256)

if __name__ == "__main__":
    main()
