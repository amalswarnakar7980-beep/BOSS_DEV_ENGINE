import json
import os
import subprocess
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path("/storage/emulated/0/BOSS_DEV_ENGINE")
CACHE = ROOT / "packages" / "cache"
REPORT = ROOT / "audit" / "execution_probe.json"

CACHE.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)

results = {
    "time": datetime.now(timezone.utc).isoformat(),
    "tests": {}
}

def record(name, function):
    try:
        result = function()
        results["tests"][name] = {
            "status": "PASS",
            "detail": result
        }
    except Exception as exc:
        results["tests"][name] = {
            "status": "FAIL",
            "detail": f"{type(exc).__name__}: {exc}"
        }

def test_system_shell():
    result = subprocess.run(
        ["/system/bin/sh", "-c", "echo BOSS_SYSTEM_SHELL_OK"],
        capture_output=True,
        text=True,
        timeout=5,
        check=False
    )
    if result.returncode != 0 or "BOSS_SYSTEM_SHELL_OK" not in result.stdout:
        raise RuntimeError(
            f"exit={result.returncode}; stderr={result.stderr.strip()}"
        )
    return result.stdout.strip()

def test_shared_storage_script():
    script = CACHE / "execution_test.sh"
    script.write_text(
        "#!/system/bin/sh\n"
        "echo BOSS_SHARED_SCRIPT_OK\n",
        encoding="utf-8"
    )

    try:
        script.chmod(0o700)
        result = subprocess.run(
            [str(script)],
            capture_output=True,
            text=True,
            timeout=5,
            check=False
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"exit={result.returncode}; stderr={result.stderr.strip()}"
            )
        return result.stdout.strip()
    finally:
        script.unlink(missing_ok=True)

record("system_shell", test_system_shell)
record("shared_storage_script_execution", test_shared_storage_script)

REPORT.write_text(json.dumps(results, indent=2), encoding="utf-8")

for name, result in results["tests"].items():
    print(f'{result["status"]}: {name}')
    print(" ", result["detail"])

print("\nReport saved:", REPORT)
print("NOTE: This tests a shell script, not an ARM64 Linux binary.")
