#include <stdio.h>

int main(void) {
    puts("BOSS_NATIVE_BINARY_OK");
    return 0;
}
