plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bossdev.engine"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bossdev.engine"
        minSdk = 23
        targetSdk = 30
        versionCode = 1
        versionName = "0.1.0"
    }
}
