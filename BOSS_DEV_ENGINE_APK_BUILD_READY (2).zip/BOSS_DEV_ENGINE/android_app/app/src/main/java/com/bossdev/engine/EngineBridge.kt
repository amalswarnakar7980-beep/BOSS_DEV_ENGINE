package com.bossdev.engine

import android.content.Context
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * BOSS Dev Engine — Android Terminal Bridge v0.1.0
 *
 * Executes user-requested commands using Android's /system/bin/sh.
 *
 * This is NOT a Linux rootfs and does NOT provide Python by itself.
 * All terminal files are kept inside the application's private storage.
 */
class EngineBridge(context: Context) {

    data class Result(
        val command: String,
        val output: String,
        val exitCode: Int,
        val workingDirectory: String,
        val timedOut: Boolean = false
    )

    private val appContext = context.applicationContext

    private val workspace = File(
        appContext.filesDir,
        "boss_workspace"
    )

    private val stateDirectory = File(
        appContext.filesDir,
        "boss_terminal"
    )

    private val cwdFile = File(
        stateDirectory,
        "working_directory.txt"
    )

    private val historyFile = File(
        stateDirectory,
        "history.log"
    )

    private val outputLog = File(
        stateDirectory,
        "output.log"
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val currentProcess = AtomicReference<Process?>(null)

    @Volatile
    private var closed = false

    init {
        workspace.mkdirs()
        stateDirectory.mkdirs()

        if (!cwdFile.exists()) {
            cwdFile.writeText(workspace.absolutePath)
        }

        if (!historyFile.exists()) {
            historyFile.createNewFile()
        }

        if (!outputLog.exists()) {
            outputLog.createNewFile()
        }

        validateWorkingDirectory()
    }

    @Synchronized
    private fun validateWorkingDirectory(): File {
        val saved = try {
            cwdFile.readText().trim()
        } catch (_: Exception) {
            ""
        }

        val candidate = if (saved.isNotEmpty()) File(saved) else workspace

        val canonicalWorkspace = workspace.canonicalFile
        val canonicalCandidate = try {
            candidate.canonicalFile
        } catch (_: Exception) {
            canonicalWorkspace
        }

        val valid =
            canonicalCandidate.path == canonicalWorkspace.path ||
            canonicalCandidate.path.startsWith(
                canonicalWorkspace.path + File.separator
            )

        val selected = if (
            valid && canonicalCandidate.isDirectory
        ) {
            canonicalCandidate
        } else {
            canonicalWorkspace
        }

        cwdFile.writeText(selected.absolutePath)
        return selected
    }

    fun getWorkingDirectory(): String {
        return validateWorkingDirectory().absolutePath
    }

    fun getWorkspacePath(): String {
        return workspace.absolutePath
    }

    fun getHistory(): String {
        return try {
            historyFile.readText()
        } catch (e: Exception) {
            "Unable to read command history: ${e.message}"
        }
    }

    fun getOutputLog(): String {
        return try {
            outputLog.readText()
        } catch (e: Exception) {
            "Unable to read output log: ${e.message}"
        }
    }

    fun execute(
        command: String,
        callback: (Result) -> Unit
    ) {
        if (closed) {
            callback(
                Result(
                    command,
                    "Engine is closed.",
                    125,
                    getWorkingDirectory()
                )
            )
            return
        }

        if (command.isBlank()) {
            callback(
                Result(
                    command,
                    "Empty command.",
                    2,
                    getWorkingDirectory()
                )
            )
            return
        }

        executor.execute {
            val result = runCommand(command)

            try {
                callback(result)
            } catch (_: Exception) {
                // A UI callback must not terminate the engine worker.
            }
        }
    }

    private fun shellQuote(value: String): String {
        return "'" + value.replace("'", "'\\''") + "'"
    }

    private fun appendLog(file: File, text: String) {
        synchronized(file) {
            file.appendText(text)
        }
    }

    private fun runCommand(command: String): Result {
        val cwd = validateWorkingDirectory()

        appendLog(
            historyFile,
            "[${System.currentTimeMillis()}] $command\n"
        )

        val markerExit = "__BOSS_EXIT_91A7__"
        val markerCwd = "__BOSS_CWD_91A7__"

        val script = """
            cd ${shellQuote(cwd.absolutePath)} || exit 125
            $command
            __boss_rc=`printf '%s' "${'$'}?"`
            printf '\n$markerExit%s\n' "${'$'}__boss_rc"
            printf '$markerCwd%s\n' "${'$'}PWD"
        """.trimIndent()

        var process: Process? = null
        var timedOut = false

        try {
            process = ProcessBuilder(
                "/system/bin/sh",
                "-c",
                script
            )
                .redirectErrorStream(true)
                .start()

            currentProcess.set(process)

            val activeProcess = process

            val watchdog = Executors.newSingleThreadScheduledExecutor()
            val timeoutTask = watchdog.schedule({
                timedOut = true
                try {
                    activeProcess.destroy()
                } catch (_: Exception) {
                }
            }, 30, TimeUnit.SECONDS)

            val rawOutput = try {
                InputStreamReader(
                    activeProcess.inputStream,
                    Charsets.UTF_8
                ).use { reader ->
                    reader.readText()
                }
            } finally {
                timeoutTask.cancel(false)
                watchdog.shutdownNow()
            }

            val completed = try {
                process.waitFor(2, TimeUnit.SECONDS)
            } catch (_: Exception) {
                false
            }

            if (!completed) {
                try {
                    process.destroy()
                } catch (_: Exception) {
                }
            }

            val exitMatch = Regex(
                Regex.escape(markerExit) + "(-?\\d+)"
            ).find(rawOutput)

            val cwdMatch = Regex(
                Regex.escape(markerCwd) + "([^\\r\\n]+)"
            ).find(rawOutput)

            val exitCode = if (timedOut) {
                124
            } else {
                exitMatch?.groupValues?.get(1)?.toIntOrNull() ?: 125
            }

            val nextCwd = cwdMatch?.groupValues?.get(1)?.trim()
            val newDirectory = if (
                !nextCwd.isNullOrEmpty()
            ) {
                File(nextCwd).canonicalFile
            } else {
                cwd
            }

            val canonicalWorkspace = workspace.canonicalFile

            val validCwd =
                newDirectory.path == canonicalWorkspace.path ||
                newDirectory.path.startsWith(
                    canonicalWorkspace.path + File.separator
                )

            val selectedCwd = if (
                validCwd && newDirectory.isDirectory
            ) {
                newDirectory
            } else {
                cwd
            }

            synchronized(this) {
                cwdFile.writeText(selectedCwd.absolutePath)
            }

            var visibleOutput = rawOutput
                .replace(
                    Regex(
                        Regex.escape(markerExit) + "-?\\d+\\r?\\n?"
                    ),
                    ""
                )
                .replace(
                    Regex(
                        Regex.escape(markerCwd) + "[^\\r\\n]*\\r?\\n?"
                    ),
                    ""
                )
                .trimEnd()

            if (timedOut) {
                visibleOutput +=
                    "\n[ BOSS ] Command timed out after 30 seconds."
            }

            if (visibleOutput.isEmpty()) {
                visibleOutput = "(no output)"
            }

            val finalResult = Result(
                command = command,
                output = visibleOutput,
                exitCode = exitCode,
                workingDirectory = selectedCwd.absolutePath,
                timedOut = timedOut
            )

            appendLog(
                outputLog,
                """
                
                [${System.currentTimeMillis()}]
                COMMAND: $command
                EXIT: ${finalResult.exitCode}
                CWD: ${finalResult.workingDirectory}
                OUTPUT:
                ${finalResult.output}
                
                """.trimIndent() + "\n"
            )

            return finalResult
        } catch (e: Exception) {
            val failure = Result(
                command = command,
                output = "Execution error: ${e.javaClass.simpleName}: ${e.message}",
                exitCode = 125,
                workingDirectory = cwd.absolutePath
            )

            appendLog(
                outputLog,
                "[ERROR] ${failure.output}\n"
            )

            return failure
        } finally {
            currentProcess.set(null)
        }
    }

    fun stopCurrentCommand() {
        try {
            currentProcess.get()?.destroy()
        } catch (_: Exception) {
        }
    }

    fun close() {
        closed = true
        stopCurrentCommand()
        executor.shutdownNow()
    }
}
