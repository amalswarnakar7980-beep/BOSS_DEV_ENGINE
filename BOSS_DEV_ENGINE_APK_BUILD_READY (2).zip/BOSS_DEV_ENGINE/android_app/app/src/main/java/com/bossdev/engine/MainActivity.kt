package com.bossdev.engine

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var engine: EngineBridge

    private var terminalOutput: TextView? = null
    private var terminalInput: EditText? = null
    private var terminalScroll: ScrollView? = null

    private val background = Color.rgb(15, 18, 28)
    private val panel = Color.rgb(27, 32, 46)
    private val accent = Color.rgb(93, 156, 255)
    private val foreground = Color.rgb(237, 241, 250)
    private val muted = Color.rgb(166, 178, 199)
    private val terminalGreen = Color.rgb(130, 230, 160)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        engine = EngineBridge(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        val header = TextView(this).apply {
            text = "BOSS DEV ENGINE"
            textSize = 23f
            setTextColor(foreground)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "Self-managed development workspace"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle)

        statusText = TextView(this).apply {
            text = "APP READY | TERMINAL INITIALIZING"
            textSize = 11f
            setTextColor(accent)
            setBackgroundColor(panel)
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        root.addView(statusText)

        val navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }

        val outerScroll = ScrollView(this)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(20))
        }

        outerScroll.addView(content)

        val pages = listOf(
            "Home", "Editor", "Terminal",
            "Packages", "Tasks", "Logs"
        )

        for (page in pages) {
            val button = Button(this).apply {
                text = page
                textSize = 9f
                isAllCaps = false
                setOnClickListener { showPage(page) }
            }

            navigation.addView(
                button,
                LinearLayout.LayoutParams(0, dp(48), 1f)
            )
        }

        root.addView(navigation)
        root.addView(
            outerScroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)
        showPage("Home")
    }

    private fun showPage(page: String) {
        content.removeAllViews()

        terminalOutput = null
        terminalInput = null
        terminalScroll = null

        when (page) {
            "Home" -> showHome()
            "Editor" -> showEditor()
            "Terminal" -> showTerminal()
            "Packages" -> showPackages()
            "Tasks" -> showTasks()
            "Logs" -> showLogs()
        }
    }

    private fun showHome() {
        addHeading("Development Dashboard")

        addCard(
            "Application",
            "BOSS Dev Engine Android shell\nVersion 0.1.0"
        )

        addCard(
            "Terminal",
            "Android shell bridge connected to the app UI.\n" +
                "Runtime: /system/bin/sh"
        )

        addCard(
            "Workspace",
            engine.getWorkspacePath()
        )

        addCard(
            "Working Directory",
            engine.getWorkingDirectory()
        )

        addCard(
            "Build Status",
            "SOURCE INTEGRATION STARTED — APK BUILD NOT VERIFIED"
        )

        addNote(
            "The Android shell is not a bundled Python runtime " +
                "or a complete Linux userspace."
        )
    }

    private fun showEditor() {
        addHeading("Code Editor")

        val editor = EditText(this).apply {
            hint = "Write or paste code here..."
            gravity = Gravity.TOP or Gravity.START
            minLines = 12
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(foreground)
            setHintTextColor(muted)
            setBackgroundColor(panel)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        content.addView(
            editor,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(300)
            )
        )

        addNote(
            "Editor UI is available. File open/save, syntax analysis " +
                "and editor-based execution are not implemented yet."
        )
    }

    private fun showTerminal() {
        addHeading("Terminal")

        addNote("Runtime: Android /system/bin/sh")

        addNote("Workspace:\n${engine.getWorkspacePath()}")

        addNote("Current directory:\n${engine.getWorkingDirectory()}")

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        val output = TextView(this).apply {
            text = "BOSS Terminal\nReady.\n"
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(terminalGreen)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            textIsSelectable = true
        }

        scroll.addView(output)

        content.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(260)
            )
        )

        terminalOutput = output
        terminalScroll = scroll

        val command = EditText(this).apply {
            hint = "Enter shell command..."
            singleLine = true
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(foreground)
            setHintTextColor(muted)
            setBackgroundColor(panel)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            imeOptions = EditorInfo.IME_ACTION_DONE
        }

        terminalInput = command

        content.addView(
            command,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val execute = makeButton("Execute")
        val stop = makeButton("Stop")
        val history = makeButton("History")

        execute.setOnClickListener {
            val text = command.text.toString()
            if (text.isNotBlank()) {
                runTerminalCommand(text)
            }
        }

        command.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val text = command.text.toString()
                if (text.isNotBlank()) {
                    runTerminalCommand(text)
                }
                true
            } else {
                false
            }
        }

        stop.setOnClickListener {
            engine.stopCurrentCommand()
            appendTerminal("\n[ BOSS ] Stop requested.\n")
        }

        history.setOnClickListener {
            appendTerminal(
                "\n--- COMMAND HISTORY ---\n" +
                    engine.getHistory() +
                    "\n--- END HISTORY ---\n"
            )
        }

        buttons.addView(
            execute,
            LinearLayout.LayoutParams(0, dp(48), 1f)
        )
        buttons.addView(
            stop,
            LinearLayout.LayoutParams(0, dp(48), 1f)
        )
        buttons.addView(
            history,
            LinearLayout.LayoutParams(0, dp(48), 1f)
        )

        content.addView(buttons)

        addNote(
            "Commands run with the Android app's OS permissions. " +
                "This is not root access. Long-running tasks are " +
                "not guaranteed to survive app termination."
        )
    }

    private fun runTerminalCommand(command: String) {
        val output = terminalOutput ?: return

        output.append(
            "\n\n$ ${command}\n[ BOSS ] Executing...\n"
        )

        statusText.text = "TERMINAL | COMMAND RUNNING"

        terminalInput?.isEnabled = false

        engine.execute(command) { result ->
            runOnUiThread {
                if (isFinishing || isDestroyed) {
                    return@runOnUiThread
                }

                val currentOutput = terminalOutput

                if (currentOutput != null) {
                    currentOutput.append(
                        "\n${result.output}\n" +
                            "[ exit=${result.exitCode} ]\n" +
                            "[ cwd=${result.workingDirectory} ]\n"
                    )

                    terminalScroll?.post {
                        terminalScroll?.fullScroll(View.FOCUS_DOWN)
                    }
                }

                terminalInput?.isEnabled = true

                statusText.text =
                    if (result.exitCode == 0) {
                        "TERMINAL | COMMAND FINISHED: SUCCESS"
                    } else {
                        "TERMINAL | EXIT CODE ${result.exitCode}"
                    }
            }
        }
    }

    private fun appendTerminal(text: String) {
        terminalOutput?.append(text)

        terminalScroll?.post {
            terminalScroll?.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun showPackages() {
        addHeading("Package Manager")

        addCard(
            "Installed Packages",
            "The Android UI is not yet connected to the " +
                "native package inventory."
        )

        addCard(
            "Repository Verification",
            "A complete trusted download/install pipeline " +
                "is not implemented."
        )

        addCard(
            "Install / Remove",
            "Package operations remain unavailable from this screen."
        )
    }

    private fun showTasks() {
        addHeading("Task Manager")

        addCard(
            "Task State",
            "Persistent background task integration is pending."
        )

        addNote(
            "The terminal executor is not an Android Foreground " +
                "Service. Process survival is not guaranteed."
        )
    }

    private fun showLogs() {
        addHeading("Logs & Diagnostics")

        addCard(
            "Terminal Output Log",
            engine.getOutputLog()
        )

        addCard(
            "Command History",
            engine.getHistory()
        )

        addNote(
            "These logs come from the app-private terminal storage. " +
                "They do not prove that an APK was built."
        )
    }

    private fun addHeading(text: String) {
        val view = TextView(this).apply {
            this.text = text
            textSize = 20f
            setTextColor(foreground)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(12))
        }

        content.addView(view)
    }

    private fun addCard(title: String, detail: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        val heading = TextView(this).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
        }

        val body = TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(foreground)
            setPadding(0, dp(8), 0, 0)
            textIsSelectable = true
        }

        card.addView(heading)
        card.addView(body)

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        params.setMargins(0, 0, 0, dp(10))
        content.addView(card, params)
    }

    private fun addNote(text: String) {
        val note = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(8))
        }

        content.addView(note)
    }

    private fun makeButton(label: String): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    override fun onDestroy() {
        if (::engine.isInitialized) {
            engine.close()
        }

        super.onDestroy()
    }
}
