#!/system/bin/sh

set -u

PROJECT="/storage/emulated/0/BOSS_DEV_ENGINE"
AUDIT_DIR="$PROJECT/audit/unified"
REPORT_DIR="$AUDIT_DIR/reports"

mkdir -p "$REPORT_DIR" || exit 1

STAMP="$(date '+%Y%m%d_%H%M%S')"
REPORT="$REPORT_DIR/unified_audit_$STAMP.txt"

PASS_COUNT=0
FAIL_COUNT=0
BLOCKED_COUNT=0
NOT_TESTED_COUNT=0

if [ -e "$REPORT" ]; then
    echo "ERROR: Report already exists: $REPORT"
    exit 1
fi

# Create report without changing application source files.
exec 3>&1

{
    echo "=================================================="
    echo " BOSS DEV ENGINE — UNIFIED AUDIT REPORT"
    echo "=================================================="
    echo "Version: 1.0"
    echo "Timestamp: $STAMP"
    echo "Project: $PROJECT"
    echo "Mode: READ-ONLY APPLICATION AUDIT"
    echo "=================================================="
    echo
} > "$REPORT"

record() {
    NAME="$1"
    STATUS="$2"
    DETAIL="$3"

    {
        echo "[$STATUS] $NAME"
        echo "  Detail: $DETAIL"
        echo
    } >> "$REPORT"

    case "$STATUS" in
        PASS) PASS_COUNT=$((PASS_COUNT + 1)) ;;
        FAIL) FAIL_COUNT=$((FAIL_COUNT + 1)) ;;
        BLOCKED) BLOCKED_COUNT=$((BLOCKED_COUNT + 1)) ;;
        NOT_TESTED) NOT_TESTED_COUNT=$((NOT_TESTED_COUNT + 1)) ;;
    esac

    printf '[%s] %s\n  %s\n' "$STATUS" "$NAME" "$DETAIL" >&3
}

has_command() {
    command -v "$1" >/dev/null 2>&1
}

file_exists() {
    [ -f "$PROJECT/$1" ]
}

echo "=== 1. ENVIRONMENT AUDIT ==="

if [ -d "$PROJECT/android_app" ] &&
   [ -n "${HOME:-}" ] &&
   [ -n "${PATH:-}" ]; then
    record "Environment" PASS \
        "Project directory and shell environment are available."
else
    record "Environment" FAIL \
        "Project directory or required shell environment is missing."
fi

echo
echo "=== 2. SOURCE INTEGRITY AUDIT ==="

SOURCE_OK=1

for f in \
    android_app/app/src/main/java/com/bossdev/engine/MainActivity.kt \
    android_app/app/src/main/java/com/bossdev/engine/EngineBridge.kt
do
    if file_exists "$f"; then
        echo "FOUND: $f" >> "$REPORT"
    else
        echo "MISSING: $f" >> "$REPORT"
        SOURCE_OK=0
    fi
done

if [ "$SOURCE_OK" -eq 1 ]; then
    record "Required Kotlin Sources" PASS \
        "Both expected Kotlin source files exist; compilation is not implied."
else
    record "Required Kotlin Sources" FAIL \
        "One or more expected Kotlin source files are missing."
fi

echo
echo "=== 3. RESOURCE AUDIT ==="

MANIFEST="android_app/app/src/main/AndroidManifest.xml"
STRINGS="android_app/app/src/main/res/values/strings.xml"
STYLES="android_app/app/src/main/res/values/styles.xml"

RESOURCE_OK=1

for f in "$MANIFEST" "$STRINGS" "$STYLES"; do
    if ! file_exists "$f"; then
        echo "MISSING: $f" >> "$REPORT"
        RESOURCE_OK=0
    fi
done

if [ "$RESOURCE_OK" -eq 1 ]; then
    if grep -q 'name="app_name"' "$PROJECT/$STRINGS" &&
       grep -q 'name="AppTheme"' "$PROJECT/$STYLES" &&
       grep -q '@string/app_name' "$PROJECT/$MANIFEST" &&
       grep -q '@style/AppTheme' "$PROJECT/$MANIFEST"; then
        record "Resource References" PASS \
            "Expected resource files and referenced names are present; full Android resource compilation is not tested."
    else
        record "Resource References" FAIL \
            "A required resource name or Manifest reference is missing."
    fi
else
    record "Resource References" FAIL \
        "One or more required Android resource files are missing."
fi

echo
echo "=== 4. BUILD CONFIGURATION AUDIT ==="

CONFIG_OK=1

for f in \
    android_app/settings.gradle.kts \
    android_app/build.gradle.kts \
    android_app/app/build.gradle.kts \
    android_app/gradle.properties
do
    if file_exists "$f"; then
        echo "FOUND: $f" >> "$REPORT"
    else
        echo "MISSING: $f" >> "$REPORT"
        CONFIG_OK=0
    fi
done

if [ "$CONFIG_OK" -eq 1 ]; then
    if grep -q 'com.android.application' \
        "$PROJECT/android_app/build.gradle.kts" &&
       grep -q 'org.jetbrains.kotlin.android' \
        "$PROJECT/android_app/build.gradle.kts" &&
       grep -q 'compileSdk' \
        "$PROJECT/android_app/app/build.gradle.kts"; then
        record "Build Configuration" PASS \
            "Expected Gradle configuration files and basic plugin declarations exist; Gradle evaluation is not tested."
    else
        record "Build Configuration" FAIL \
            "A required basic plugin or compileSdk declaration is missing."
    fi
else
    record "Build Configuration" FAIL \
        "One or more required Gradle configuration files are missing."
fi

echo
echo "=== 5. TOOLCHAIN AUDIT ==="

JAVA_OK=0
GRADLE_OK=0
KOTLINC_OK=0
SDK_OK=0

if has_command java; then
    JAVA_OK=1
    echo "java: $(command -v java)" >> "$REPORT"
else
    echo "java: NOT FOUND IN PATH" >> "$REPORT"
fi

if has_command gradle; then
    GRADLE_OK=1
    echo "gradle: $(command -v gradle)" >> "$REPORT"
else
    echo "gradle: NOT FOUND IN PATH" >> "$REPORT"
fi

if has_command kotlinc; then
    KOTLINC_OK=1
    echo "kotlinc: $(command -v kotlinc)" >> "$REPORT"
else
    echo "kotlinc: NOT FOUND IN PATH" >> "$REPORT"
fi

if [ -n "${ANDROID_HOME:-}" ] &&
   [ -d "$ANDROID_HOME/platforms" ]; then
    SDK_OK=1
    echo "ANDROID_HOME: $ANDROID_HOME" >> "$REPORT"
elif [ -n "${ANDROID_SDK_ROOT:-}" ] &&
     [ -d "$ANDROID_SDK_ROOT/platforms" ]; then
    SDK_OK=1
    echo "ANDROID_SDK_ROOT: $ANDROID_SDK_ROOT" >> "$REPORT"
else
    echo "Android SDK: NOT CONFIRMED" >> "$REPORT"
fi

if [ "$JAVA_OK" -eq 1 ] &&
   [ "$GRADLE_OK" -eq 1 ] &&
   [ "$SDK_OK" -eq 1 ]; then
    record "Build Toolchain Availability" PASS \
        "Java, Gradle and an Android SDK platforms directory were found; actual build compatibility remains unverified."
else
    record "Build Toolchain Availability" BLOCKED \
        "At least one essential build component is unavailable or unconfirmed. See tool inventory in report."
fi

echo
echo "=== 6. GRADLE WRAPPER AUDIT ==="

WRAPPER_FOUND=0

for f in \
    android_app/gradlew \
    android_app/gradle/wrapper/gradle-wrapper.jar \
    android_app/gradle/wrapper/gradle-wrapper.properties
do
    if file_exists "$f"; then
        echo "FOUND: $f" >> "$REPORT"
        case "$f" in
            android_app/gradlew) WRAPPER_FOUND=1 ;;
        esac
    else
        echo "NOT FOUND: $f" >> "$REPORT"
    fi
done

if [ "$WRAPPER_FOUND" -eq 1 ]; then
    record "Gradle Wrapper" PASS \
        "Wrapper script exists; wrapper JAR and properties must also be present for a usable wrapper."
else
    record "Gradle Wrapper" BLOCKED \
        "Gradle wrapper script is absent; no wrapper-based build can be started from this project as-is."
fi

echo
echo "=== 7. DEPENDENCY DECLARATION AUDIT ==="

if file_exists "android_app/settings.gradle.kts" &&
   grep -q 'google()' "$PROJECT/android_app/settings.gradle.kts" &&
   grep -q 'mavenCentral()' "$PROJECT/android_app/settings.gradle.kts" &&
   grep -q 'gradlePluginPortal()' "$PROJECT/android_app/settings.gradle.kts"; then
    record "Repository Declarations" PASS \
        "Expected repository declarations exist; network access, resolution and dependency integrity were not tested."
else
    record "Repository Declarations" FAIL \
        "Expected Gradle repository declarations are missing."
fi

record "Resolved Dependency Verification" NOT_TESTED \
    "Cannot verify resolved plugins or dependencies without running Gradle dependency resolution."

echo
echo "=== 8. BASIC SECURITY CONFIGURATION AUDIT ==="

SECURITY_OK=1

if file_exists "$MANIFEST"; then
    if grep -q 'allowBackup="false"' "$PROJECT/$MANIFEST"; then
        echo "Manifest: allowBackup=false" >> "$REPORT"
    else
        echo "Manifest: allowBackup=false not confirmed" >> "$REPORT"
        SECURITY_OK=0
    fi

    if grep -q 'usesCleartextTraffic="false"' "$PROJECT/$MANIFEST"; then
        echo "Manifest: usesCleartextTraffic=false" >> "$REPORT"
    else
        echo "Manifest: cleartext restriction not confirmed" >> "$REPORT"
        SECURITY_OK=0
    fi
else
    SECURITY_OK=0
fi

if [ "$SECURITY_OK" -eq 1 ]; then
    record "Basic Manifest Security Checks" PASS \
        "Backup and cleartext configuration declarations are present; this is not a complete security audit."
else
    record "Basic Manifest Security Checks" FAIL \
        "One or more expected security declarations are missing or unconfirmed."
fi

record "Full Security Assessment" NOT_TESTED \
    "Component-level security, runtime behavior, dependency vulnerabilities and signing configuration have not been fully assessed."

echo
echo "=== 9. BUILD READINESS AUDIT ==="

if [ "$CONFIG_OK" -eq 1 ] &&
   [ "$SOURCE_OK" -eq 1 ] &&
   [ "$RESOURCE_OK" -eq 1 ] &&
   [ "$JAVA_OK" -eq 1 ] &&
   [ "$GRADLE_OK" -eq 1 ] &&
   [ "$SDK_OK" -eq 1 ]; then
    record "Build Readiness" NOT_TESTED \
        "Prerequisites appear present, but only an actual build can establish build success."
else
    record "Build Readiness" BLOCKED \
        "One or more required sources, configurations or build tools are missing or unconfirmed."
fi

echo
echo "=== 10. TEST AND ARTIFACT INVENTORY ==="

APK_FOUND=0
TEST_FOUND=0

if [ -d "$PROJECT/android_app" ]; then
    if find "$PROJECT/android_app" -type f -name '*.apk' -print \
        >> "$REPORT" 2>/dev/null; then
        :
    fi
fi

if find "$PROJECT/android_app" -type f -name '*.apk' \
    -print 2>/dev/null | grep -q .; then
    APK_FOUND=1
fi

if [ -d "$PROJECT/tests" ]; then
    if find "$PROJECT/tests" -type f -print 2>/dev/null |
       grep -q .; then
        TEST_FOUND=1
    fi
fi

if [ "$APK_FOUND" -eq 1 ]; then
    record "APK Inventory" PASS \
        "At least one APK file exists under android_app; installation and runtime validity are not implied."
else
    record "APK Inventory" BLOCKED \
        "No APK was found under android_app."
fi

if [ "$TEST_FOUND" -eq 1 ]; then
    record "Test Inventory" PASS \
        "At least one file exists under tests; test execution and coverage are not implied."
else
    record "Test Inventory" NOT_TESTED \
        "No test files were found under the project's tests directory."
fi

echo
echo "=== FINAL SUMMARY ==="

if [ "$FAIL_COUNT" -gt 0 ]; then
    OVERALL="FAIL"
elif [ "$BLOCKED_COUNT" -gt 0 ]; then
    OVERALL="BLOCKED"
elif [ "$NOT_TESTED_COUNT" -gt 0 ]; then
    OVERALL="INCOMPLETE"
else
    OVERALL="PASS"
fi

{
    echo "=================================================="
    echo "FINAL SUMMARY"
    echo "=================================================="
    echo "PASS: $PASS_COUNT"
    echo "FAIL: $FAIL_COUNT"
    echo "BLOCKED: $BLOCKED_COUNT"
    echo "NOT_TESTED: $NOT_TESTED_COUNT"
    echo "OVERALL: $OVERALL"
    echo
    echo "IMPORTANT:"
    echo "- Source presence does not prove successful compilation."
    echo "- Build readiness does not prove an APK can be built."
    echo "- APK presence does not prove successful installation or runtime."
    echo "- This bundle performs checks only; it does not modify application source."
    echo
    echo "Report: $REPORT"
} >> "$REPORT"

echo "----------------------------------------------"
echo "PASS: $PASS_COUNT"
echo "FAIL: $FAIL_COUNT"
echo "BLOCKED: $BLOCKED_COUNT"
echo "NOT_TESTED: $NOT_TESTED_COUNT"
echo "OVERALL: $OVERALL"
echo "----------------------------------------------"
echo "Report saved:"
echo "$REPORT"

case "$OVERALL" in
    PASS) exit 0 ;;
    *) exit 1 ;;
esac
